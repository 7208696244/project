  		
	<?php include('tooltip.php'); ?>			
	<div class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="nav-collapse collapse">
					<ul class="nav">
					<li class="divider-vertical"></li><li class=""><a  rel="tooltip"  data-placement="bottom" title="Home" id="home"   href="index.php"><i class="icon-home icon-large"></i>&nbsp;Home</a> </li>
					<li class="divider-vertical"></li>
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="about.php"><i class="icon-info-sign icon-large"></i>&nbsp;About</a> 
					</li>
					<li class="divider-vertical"></li>
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="librarian"><i class="icon-user icon-large"></i>&nbsp;Admin</a>
					</li>
					<li class="divider-vertical"></li>
					<li class="divider-vertical"></li>
					<li class="divider-vertical"></li>
				
					<li class="divider-vertical"></li>
					<li class="signup"><span class="sg"></span></li>
					</ul>

			

                    
						

                    </div>
                </div>
            </div>
        </div>
   

	     	